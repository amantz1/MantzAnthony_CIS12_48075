<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Intro to PHP 3 of 13
	*/
?>
<!DOCTYPE html>
<html>
	<head>
        <link type="text/css" rel="stylesheet" href="style.css"/>
		<title>Summing Things Up</title>
	</head>
	<body>
        <p>
            <?php echo "Anthony Mantz"; ?>
        </p>   
	</body>
</html>