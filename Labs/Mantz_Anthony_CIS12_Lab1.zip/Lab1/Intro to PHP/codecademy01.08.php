<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Intro to PHP 8 of 13
	*/
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Variable Magic</title>
	</head>
	<body>
        <!-- Add your PHP code between the <p></p> tags! -->
        <p><?php
            $myName = "Anthony";
        ?></p>
    </body>
</html>