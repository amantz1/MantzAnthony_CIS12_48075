<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Intro to PHP 10 of 13
	*/
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Oh No!</title>
	</head>
	<body>
        <p><?php
            echo "Oh, the humanity!";
            //This is a comment
          ?></p>
    </body>
</html>