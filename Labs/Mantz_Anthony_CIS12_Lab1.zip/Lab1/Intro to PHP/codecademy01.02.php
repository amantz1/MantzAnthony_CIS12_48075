<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Intro to PHP 2 of 13
	*/
?>
<!DOCTYPE html>
<html>
    <head>
	</head>
	<body>
        <p>
          <?php
            echo "My first line of PHP!"; 
          ?>
        </p>
	</body>
</html>