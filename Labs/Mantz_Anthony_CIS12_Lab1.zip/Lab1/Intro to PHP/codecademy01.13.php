<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Intro to PHP 13 of 13
	*/
?>
<!DOCTYPE html>
<html>
    <head>
        <link type='text/css' rel='stylesheet' href='style.css'/>
		<title>PHP FTW!</title>
	</head>
	<body>
        <!-- Write your PHP code below!-->
        <p><?php
            $myName="Anthony";
            $myAge=35;
            echo $myName;
            echo $myAge;
        ?></p>   
	</body>
</html>