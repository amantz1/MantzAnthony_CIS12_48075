<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Intro to PHP 5 of 13
	*/
?>
<!DOCTYPE html>
<html>
    <head>
	</head>
	<body>
        <h1>
          <?php
             echo "I'm learning PHP.";   
          ?>
        </h1>
	</body>
</html>