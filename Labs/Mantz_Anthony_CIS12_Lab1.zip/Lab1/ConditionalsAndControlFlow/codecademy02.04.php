<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Conditionals and Control Flow 4 of 4
	*/
?>
<html>
  <head>
  </head>
  <body>
    <p>
      <?php
        // Write your if/elseif/else statement here!
        if(7<5){
        echo "The condition is true";
        }
        else {
        echo "The condition is false";
        }
      ?>
    </p>
  </body>
</html>