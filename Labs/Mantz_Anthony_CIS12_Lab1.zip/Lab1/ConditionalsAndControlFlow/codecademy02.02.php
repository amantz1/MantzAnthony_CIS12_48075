<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Conditionals and Control Flow 2 of 4
	*/
?>
<html>
  <head>
    <title>Our Shop</title>
  </head>
  <body>
    <p>
      <?php
        $items =  7 ;  // Set this to a number greater than 5!
        if ($items > 5) {
          echo "You get a 10% discount!";
        }
      ?>
    </p>
  </body>
</html>