<?php
	/*	Anthony Mantz
		September 5, 2014
		Lab 1: Codecademy Conditionals and Control Flow 1 of 4
	*/
?>
<html>
  <head>
    <title>Comparing Numbers</title>
  </head>
  <body>
    <p>
      <?php
      $something=5;
        if(7>3){
            echo "true";
        };
      ?>
    </p>
  </body>
</html>