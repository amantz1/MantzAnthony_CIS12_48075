<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Control Flow: Switch 6 of 6
	*/
?>

<!DOCTYPE html>
<html>
    <head>
		<title></title>
	</head>
	<body>
    <?php
     $myvar=3;
     switch ($myvar){
         case 1:
             print "The number is 1";
             break;
        case 2:
            print "The number is 2";
            break;
        case 3:
            print "The number is 3";
            break;
        default:;
     }
    ?>
	</body>
</html>