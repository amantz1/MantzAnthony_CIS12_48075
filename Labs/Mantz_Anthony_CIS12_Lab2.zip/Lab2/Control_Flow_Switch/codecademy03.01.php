<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Control Flow: Switch 1 of 6
	*/
?>

<!DOCTYPE html>
<html>
    <head>
		<title></title>
	</head>
	<body>
    <?php
        $myvar=25;
        if($myvar>25){
            print "higher";
        }
        elseif($myvar<25){
            print "lower";
        }
        else print "equals";
    ?>
    </body>
</html>