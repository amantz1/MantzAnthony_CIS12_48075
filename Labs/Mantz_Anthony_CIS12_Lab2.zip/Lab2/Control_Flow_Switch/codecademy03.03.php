<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Control Flow: Switch 3 of 6
	*/
?>

<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>
    <?php
    $fruit = "Apple";
    
    switch ($fruit) {
        case 'Apple':
            echo "Yummy.";
            break;
        default:;
    }
    
    ?>
    </body>
</html>