<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Arrays 3 of 7
	*/
?>

<html>
  <head>
    <title>My First Array</title>
  </head>
  <body>
    <p>
      <?php
        $friends=array("Friend1", "Friend2", "Friend3");
      ?>
    </p>
  </body>
</html>