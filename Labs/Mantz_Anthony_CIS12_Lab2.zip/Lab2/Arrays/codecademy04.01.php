<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Arrays 1 of 7
	*/
?>

<html>
  <head>
    <title>Woot, Arrays!</title>
  </head>
  <body>
    <?php
      $array = array("Egg", "Tomato", "Beans");
    ?>    
  </body>
</html>