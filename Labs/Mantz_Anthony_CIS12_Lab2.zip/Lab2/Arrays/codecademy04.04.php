<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Arrays 4 of 7
	*/
?>

<html>
  <head>
    <title>Accessing Elements</title>
  </head>
  <body>
    <p>
      <?php
        $tens = array(10, 20, 30, 40, 50);
        print $tens[2];
      ?>
    </p>
  </body>
</html>