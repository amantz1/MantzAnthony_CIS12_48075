<?php
	/*	Anthony Mantz
		September 16, 2014
		Lab 2: Codecademy Arrays 2 of 7
	*/
?>

<html>
  <head>
    <title>Woot, More Arrays!</title>
  </head>
  <body>
    <p>
      <?php
        // Add your array elements after
        // "Beans" and before the final ")"
        $array = array("Egg", "Tomato", "Beans", "Chips", "Sausage" );        
      ?>
    </p>
  </body>
</html>